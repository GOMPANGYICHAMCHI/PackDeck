using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SelectedCardScript : CardBasic
{
    public int ObjectIndex;
    
    public Button selfBtn;
}
