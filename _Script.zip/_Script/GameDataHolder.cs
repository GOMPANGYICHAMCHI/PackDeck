using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameDataHolder : MonoBehaviour
{
    [Header("메인 게임 데이터")]
    public GameDataSobject OriginalGameData;
}
