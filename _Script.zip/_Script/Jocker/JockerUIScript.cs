using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class JockerUIScript : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    public delegate void PointerJockerInfo(JockerBase input_jocker);

    public int Index;

    public GameObject DisablePannel;

    public JockerBase jockerInfo;

    public PointerJockerInfo func_PoinetEnter;
    public PointerJockerInfo func_PoinetExit;

    private void Start()
    {
        DisablePannel = transform.GetChild(1).gameObject; 
    }

    public void SetActiveDisablePannel(bool isActive)
    {
        DisablePannel.SetActive(isActive);
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        func_PoinetEnter?.Invoke(jockerInfo);
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        func_PoinetExit?.Invoke(jockerInfo);
    }
}
