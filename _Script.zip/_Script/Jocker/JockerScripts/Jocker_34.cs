using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "Jocker_34", menuName = "Scriptable Object/Jocker/Jocker_34")]
public class Jocker_34 : JockerBase
{
    [Header("오버딜 보상 곱")]
    public int OverdealRewardMulAmount;

    [Header("오버딜 보상 한도")]
    public int OverdealRewardLimit;

    public override GoldRewardData Event_CheckAddGold(GoldRewardData goldReward)
    {
        goldReward.overDealBonus *= OverdealRewardMulAmount;
        goldReward.overDealBonus = Mathf.Clamp(goldReward.overDealBonus, 0, OverdealRewardLimit);

        return goldReward;
    }
}
