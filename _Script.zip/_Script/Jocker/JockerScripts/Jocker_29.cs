using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "Jocker_29", menuName = "Scriptable Object/Jocker/Jocker_29")]
public class Jocker_29 : JockerBase
{
    [Header("삼각형 버프 c 곱산양")]
    public float mulBuff;

    [Header("나머지 도형 디버프 c 곱산양")]
    public float mulDeBuff;

    public override ScoreData Event_CheckScore(ScoreData scoreData, PlayerData playerData)
    {
        for (int i = 0; i < scoreData.patternCardCount[2]; i++)
        {
            scoreData.Additional.Pattern_Multiply[2] *= mulBuff;
        }

        if (scoreData.patternCardCount[1] != 0 || scoreData.patternCardCount[0] != 0)
        {
            for (int i = 0; i < scoreData.Additional.patternCount; i++)
            {
                scoreData.Additional.Pattern_Multiply[i] *= mulDeBuff;
            }

            for (int i = 0; i < scoreData.Additional.colorCount; i++)
            {
                scoreData.Additional.Color_Multiply[i] *= mulDeBuff;
            }
        }

        return scoreData;
    }
}
