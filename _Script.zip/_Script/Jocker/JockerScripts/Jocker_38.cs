using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "Jocker_38", menuName = "Scriptable Object/Jocker/Jocker_38")]
public class Jocker_38 : JockerBase
{
    [Header("전체 c 곱 정도")]
    public int mulAmount;

    [Header("스테이지 종료 이후 소멸 확률")]
    public int ExtinctionPercent;

    public override ScoreData Event_CheckScore(ScoreData scoreData, PlayerData playerData)
    {
        for (int i = 0; i < scoreData.Additional.patternCount; i++)
        {
            scoreData.Additional.Pattern_A[i] *= mulAmount;
        }

        for (int i = 0; i < scoreData.Additional.colorCount; i++)
        {
            scoreData.Additional.Color_A[i] *= mulAmount;
        }

        return scoreData;
    }

    public override void Event_StageEnd(PlayerData playerData) 
    {
        int rand = Random.Range(0, 101);

        if (rand <= ExtinctionPercent)
        {
            playerData.Remove_PlayerJocker(this);
        }
    }
}
