using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "Jocker_32", menuName = "Scriptable Object/Jocker/Jocker_32")]
public class Jocker_32 : JockerBase
{
    [Header("버프 발동 조건 카드 숫자 합 (이하)")]
    public int CardNumSumForBuff;

    [Header("C + addAmount")]
    public int addAmount;

    public override ScoreData Event_CheckScore(ScoreData scoreData, PlayerData playerData)
    {
        int numberSum = 0;

        for (int i = 0; i < scoreData.Additional.patternCount; i++)
        {
            numberSum += scoreData.patternNumberSum[i];
        }

        for (int i = 0; i < scoreData.Additional.colorCount; i++)
        {
            numberSum += scoreData.colorNumberSum[i];
        }

        if(numberSum <= CardNumSumForBuff)
        {
            for (int i = 0; i < scoreData.Additional.patternCount; i++)
            {
                scoreData.Additional.Pattern_Multiply[i] += addAmount;
            }

            for (int i = 0; i < scoreData.Additional.colorCount; i++)
            {
                scoreData.Additional.Color_Multiply[i] += addAmount;
            }
        }

        return scoreData;
    }
}
