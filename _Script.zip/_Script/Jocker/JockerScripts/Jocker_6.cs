using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "Jocker_6", menuName = "Scriptable Object/Jocker/Jocker_6")]
public class Jocker_6 : JockerBase
{
    [Header("b + addAmount")]
    public float addAmount;

    public override ScoreData Event_CheckScore(ScoreData scoreData, PlayerData playerData)
    {
        for (int i = 0; i < scoreData.Additional.colorCount; i++)
        {
            scoreData.Additional.Color_B[i] += addAmount;
        }

        return scoreData;
    }
}
