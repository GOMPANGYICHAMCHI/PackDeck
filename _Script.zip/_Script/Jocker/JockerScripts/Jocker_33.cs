using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "Jocker_33", menuName = "Scriptable Object/Jocker/Jocker_33")]
public class Jocker_33 : JockerBase
{
    [Header("효과 발동 조건, 남은 몬스터체력 ( 10% -> 10 )")]
    public int MonsterHealthPercentForEffect;

    public override void Event_CardPlayEndStart(PlayerData playerData)
    {
        ulong BasicHealth = playerData.Get_BasicHealth();
        ulong RemainHealth = playerData.Get_RemainHealth();

        if(playerData.Get_CurrentActionCost() == 0 && BasicHealth / (BasicHealth - RemainHealth) <= (float)MonsterHealthPercentForEffect)
        {
            playerData.Add_CurrentActionCost(1);
            playerData.Remove_PlayerJocker(this);
        }
    }
}
