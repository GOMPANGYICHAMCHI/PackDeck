using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "Jocker_31", menuName = "Scriptable Object/Jocker/Jocker_31")]
public class Jocker_31 : JockerBase
{
    [Header("원 버프 c 곱산양")]
    public float mulBuff;

    [Header("나머지 도형 디버프 c 곱산양")]
    public float mulDeBuff;

    public override ScoreData Event_CheckScore(ScoreData scoreData, PlayerData playerData)
    {
        for (int i = 0; i < scoreData.patternCardCount[0]; i++)
        {
            scoreData.Additional.Pattern_Multiply[0] *= mulBuff;
        }

        if (scoreData.patternCardCount[1] != 0 || scoreData.patternCardCount[2] != 0)
        {
            for (int i = 0; i < scoreData.Additional.patternCount; i++)
            {
                scoreData.Additional.Pattern_Multiply[i] *= mulDeBuff;
            }

            for (int i = 0; i < scoreData.Additional.colorCount; i++)
            {
                scoreData.Additional.Color_Multiply[i] *= mulDeBuff;
            }
        }

        return scoreData;
    }
}
