using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "Jocker_7", menuName = "Scriptable Object/Jocker/Jocker_7")]
public class Jocker_7 : JockerBase
{
    public override void Event_GetItem(PlayerData playerData)
    {
        base.Event_GetItem(playerData);
        playerData.Add_HandSize(1);
    }

    public override void Event_Sell(PlayerData playerData)
    {
        base.Event_Sell(playerData);
        if (isActive)
        {
            playerData.Add_HandSize(-1);
        }
    }

    public override void Event_isActiveChanged(PlayerData playerData) 
    { 
        if (isActive)
        {
            playerData.Add_HandSize(1);
        }
        else
        {
            playerData.Add_HandSize(-1);
        }
    }
}
