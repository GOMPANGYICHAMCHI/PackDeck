using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "Jocker_40", menuName = "Scriptable Object/Jocker/Jocker_40")]
public class Jocker_40 : JockerBase
{
    [Header("b + addAmount")]
    public int addAmount;

    bool[] patternUsed;
    bool[] colorUsed;

    void ResetUsedValue()
    {
        for (int i = 0; i < patternUsed.Length; i++)
        {
            patternUsed[i] = false;
        }
        for (int i = 0; i < colorUsed.Length; i++)
        {
            patternUsed[i] = false;
        }
    }

    public override void Event_GetItem(PlayerData playerData)
    {
        base.Event_GetItem(playerData);
        patternUsed = new bool[playerData.PatternCount];
        colorUsed = new bool[playerData.ColorCount];
        ResetUsedValue();
    }

    public override void Event_StageEnd(PlayerData playerData) 
    {
        ResetUsedValue();
    }

    public override ScoreData Event_CheckScore(ScoreData scoreData, PlayerData playerData)
    {
        for (int i = 0; i < scoreData.Additional.patternCount; i++)
        {
            if (patternUsed[i])
            {
                scoreData.Additional.Pattern_B[i] += addAmount;
            }
            else if (scoreData.patternCardCount[i] != 0)
            {
                patternUsed[i] = true;
            }
        }

        for (int i = 0; i < scoreData.Additional.colorCount; i++)
        {
            if (colorUsed[i])
            {
                scoreData.Additional.Color_B[i] += addAmount;
            }
            else if (scoreData.colorCardCount[i] != 0)
            {
                colorUsed[i] = true;
            }
        }

        return scoreData;
    }
}
