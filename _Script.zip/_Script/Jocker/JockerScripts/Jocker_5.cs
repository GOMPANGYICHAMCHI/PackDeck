using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "Jocker_5", menuName = "Scriptable Object/Jocker/Jocker_5")]
public class Jocker_5 : JockerBase
{
    [Header("b + addAmount")]
    public float addAmount;

    public override ScoreData Event_CheckScore(ScoreData scoreData, PlayerData playerData)
    {
        for (int i = 0; i < scoreData.Additional.patternCount; i++)
        {
            scoreData.Additional.Pattern_B[i] += addAmount;
        }

        return scoreData;
    }
}
