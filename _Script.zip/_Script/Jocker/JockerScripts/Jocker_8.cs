using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "Jocker_8", menuName = "Scriptable Object/Jocker/Jocker_8")]
public class Jocker_8 : JockerBase
{
    public override void Event_GetItem(PlayerData playerData)
    {
        base.Event_GetItem(playerData);
        playerData.Add_DumpCost(1);
    }

    public override void Event_Sell(PlayerData playerData)
    {
        base.Event_Sell(playerData);
        if (isActive)
        {
            playerData.Add_DumpCost(-1);
        }
    }

    public override void Event_isActiveChanged(PlayerData playerData)
    {
        if (isActive)
        {
            playerData.Add_DumpCost(1);
        }
        else
        {
            playerData.Add_DumpCost(-1);
        }
    }
}
