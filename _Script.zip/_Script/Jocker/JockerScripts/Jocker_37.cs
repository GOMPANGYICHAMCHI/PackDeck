using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "Jocker_37", menuName = "Scriptable Object/Jocker/Jocker_37")]
public class Jocker_37 : JockerBase
{
    [Header("기본 전체 c 곱 정도")]
    public float BasicMulAmount;

    [Header("사용된 버리기 마다 곱 감소 정도")]
    public float ReduceAmountPerDump;

    public override ScoreData Event_CheckScore(ScoreData scoreData, PlayerData playerData)
    {
        float multiplyAmount = BasicMulAmount;

        multiplyAmount -= (playerData.Get_DumpCost() - playerData.Get_CurrentDumpCost()) * ReduceAmountPerDump;

        for (int i = 0; i < scoreData.Additional.patternCount; i++)
        {
            scoreData.Additional.Pattern_Multiply[i] *= multiplyAmount;
        }

        for (int i = 0; i < scoreData.Additional.colorCount; i++)
        {
            scoreData.Additional.Pattern_Multiply[i] *= multiplyAmount;
        }

        return scoreData;
    }
}
