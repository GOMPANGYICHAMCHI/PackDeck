using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "Jocker_4", menuName = "Scriptable Object/Jocker/Jocker_4")]
public class Jocker_4 : JockerBase
{
    [Header("b + addAmount")]
    public int addAmount;

    public override ScoreData Event_CheckScore(ScoreData scoreData, PlayerData playerData)
    {
        for (int i = 0; i < scoreData.Additional.patternCount; i++) 
        {
            scoreData.Additional.Pattern_B[i] += addAmount;
        }

        for (int i = 0; i < scoreData.Additional.colorCount; i++)
        {
            scoreData.Additional.Color_B[i] += addAmount;
        }

        return scoreData;
    }
}
