using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "Jocker_35", menuName = "Scriptable Object/Jocker/Jocker_35")]
public class Jocker_35 : JockerBase
{
    [Header("외상 가능 정도")]
    public int AvailableMinusAmount;

    public override void Event_GetItem(PlayerData playerData)
    {
        base.Event_GetItem(playerData);
        playerData.Set_PurchaseLimit(AvailableMinusAmount);
    }

    public override void Event_Sell(PlayerData playerData)
    {
        base.Event_Sell(playerData);
        playerData.Reset_PurchaseLimit();
    }
}
